import json
import boto3
from boto3.dynamodb.conditions import Key

client = boto3.client('dynamodb')
DB = boto3.resource('dynamodb')
tableName='Customer_Details'
table = DB.Table(tableName)

def lambda_handler(event, context):
    
    try:
        
        FE = Key('Telephone_Number').eq(event['key1'])
        PE = "Telephone_Number,Telephone_Password"
        
        resp = table.scan(
            FilterExpression=FE,
            ProjectionExpression=PE
            )
        
        if resp['Items']:
            for item in resp['Items']:
                op = item.get('Telephone_Password')
                if op > 0:
                    result = print ("Customer's telephone number exists and have password -", op)
                elif op == 0:
                    result = print ("Customer's telephone number exists but doesn't have password -", op)
        else:
            result = print ('Customer does not exists!')
            
        print (result)

    except Exception as E:
        print ('Error in returning data..')
        raise E
    
    return {
        'statusCode': 200,
        'output1': resp['Items'],
        'output2': result
    }
