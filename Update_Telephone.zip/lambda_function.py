import json
import boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

client = boto3.client('dynamodb')
DB = boto3.resource('dynamodb')
tableName='Customer_Details'
table = DB.Table(tableName)
s3_client = boto3.client('s3')

def lambda_handler(event, context):
    
    In_Number = event['key1']
    In_Password = event['key2']
    Cust_ID = event['key3']
    
    try:
        
        if not (len(In_Password) == 6):
          return "Password must be 6 digit"
            
        resp = table.update_item(
            Key={'Customer_ID': Cust_ID},
            UpdateExpression="SET Telephone_Password = :p",
            ExpressionAttributeValues={':p': In_Password},
            ReturnValues="UPDATED_NEW"
            )
        
        print('Telephone Password Updated Successfully!!')
        
        createS3 = createS3_upload(In_Number, In_Password)
        
        resp = table.update_item(
        Key={'Customer_ID': Cust_ID},
        UpdateExpression="SET File_Name = :FN, File_Size = :FS, File_Created_Timestamp = :FCT",
        ExpressionAttributeValues={
            ':FN': records['File_name'],
            ':FS': records['File_size'],
            ':FCT': records['File_time'],
            },
        ReturnValues="UPDATED_NEW"
        )
                
        print (resp['Item'])
        print('File name and other details updated successfully!!')
        
        
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        return resp['Item']
        
def createS3_upload(In_Number, In_Password):
    try:
        bucket='cust-contact-details'
        key = '{}.txt'.format(In_Number)
        
        s3_client.put_object(
            Body='{},{}'.format(In_Password, In_Number),
            Bucket=bucket,
            Key=key
            )
        
        data = s3_client.get_object(Bucket=bucket, Key=key)
        
        object_info = {
          'File_name': key,
          'File_size': data['ContentLength'],
          'File_time': data['LastModified'].isoformat()
        }

    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        return object_info
        